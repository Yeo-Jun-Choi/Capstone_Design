#ifndef RTW_HEADER_OtherControlComponents_capi_h_
#define RTW_HEADER_OtherControlComponents_capi_h_
#include "OtherControlComponents.h"
extern void OtherControlComponents_InitializeDataMapInfo ( lij0uujly1 * const
kmnlllhkv2 , void * sysRanPtr , int contextTid ) ;
#endif
